package item;

public class Weapon extends Item{
    private final double dmgMultiplier;
    public Weapon(String name, String description, int amount, double dmgMultiplier){
        super(name, description, amount);
        this.dmgMultiplier = dmgMultiplier;
    }
    public double getDmgMultiplier(){
        return dmgMultiplier;
    }
    @Override
    public void useItem(entity.Character player) {
        System.out.println(this.name +" equipped! Buffed atk by " + getDmgMultiplier());
        player.setWeaponEquipped(this);
    }
    public String toSaveString() {
        return "Weapon," + getName() + "," + getAmount() + "," + getDmgMultiplier();
    }
}
